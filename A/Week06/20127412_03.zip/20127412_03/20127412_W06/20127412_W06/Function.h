#pragma once
#include <iostream>
using namespace std;

void input_SoNguyenKhongAm(int& n);
void input_SoNguyenDuong(int& n);
int P42_findK(int n);
int P46_count(int n);
int P50_reverse(int n);
